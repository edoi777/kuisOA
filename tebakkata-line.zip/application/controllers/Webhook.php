<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Webhook extends CI_Controller {

	private $myUID = "U3cc5055a5edee58cec04540a1ed0fe02";

	public function index()
	{
		$this->load->model('line_model');

		
	}

}
